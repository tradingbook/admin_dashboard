export const ecommerceData = [
    {
        id: 1,
        product: 'email-template/4.png',
        desc: 'Three seater Wood Style sofa for Leavingroom',
        size: 'L',
        qty: '1',
        price: '500'
    },
    {
        id: 2,
        product: 'email-template/1.png',
        desc: 'Three seater Wood Style sofa for Leavingroom',
        size: 'L',
        qty: '1',
        price: '500'
    },
    {
        id: 3,
        product: 'email-template/4.png',
        desc: 'Three seater Wood Style sofa for Leavingroom',
        size: 'L',
        qty: '1',
        price: '500'
    },
    {
        id: 4,
        product: 'email-template/1.png',
        desc: 'Three seater Wood Style sofa for Leavingroom',
        size: 'L',
        qty: '1',
        price: '500'
    }
];

export const productData = [
    {
        id: 1,
        img: 'email-template/2.png',
        title: 'When an unknown.',
        price: '$45.00',
        star: false
    },
    {
        id: 2,
        img: 'email-template/2.png',
        title: 'When an unknown.',
        price: '$45.00',
        star: true
    },
    {
        id: 3,
        img: 'email-template/2.png',
        title: 'When an unknown.',
        price: '$45.00',
        star: true
    }
];