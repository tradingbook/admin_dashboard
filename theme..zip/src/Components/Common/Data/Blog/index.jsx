import comment from '../../../../assets/images/blog/comment.jpg';
import Men from '../../../../assets/images/blog/12.png';
import Boy from '../../../../assets/images/blog/14.png';
export const BlogData = [
  {
    id: 1,
    img: 'blog/blog-5.jpg',
    date: '9 April 2022',
    admin: 'by: Admin',
    hits: '0 Hits',
    details: 'Perspiciatis unde omnis iste natus error sit.Dummy text',
  },
  {
    id: 2,
    img: 'blog/blog-6.jpg',
    date: '9 April 2022',
    admin: 'by: Admin',
    hits: '0 Hits',
    details: 'Perspiciatis unde omnis iste natus error sit.Dummy text',
  },
  {
    id: 3,
    img: 'blog/blog-5.jpg',
    date: '9 April 2022',
    admin: 'by: Admin',
    hits: '0 Hits',
    details: 'Perspiciatis unde omnis iste natus error sit.Dummy text',
  },
  {
    id: 4,
    img: 'blog/blog-6.jpg',
    date: '9 April 2022',
    admin: 'by: Admin',
    hits: '0 Hits',
    details: 'Perspiciatis unde omnis iste natus error sit.Dummy text',
  },
];

export const BlogSingleData = [
  {
    id: 1,
    src: Men,
    name: 'Mark Jolio',
    post: 'Designer',
    hits: '02 Hits',
    comments: '598 Comments',
    para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`,
  },
  {
    id: 2,
    src: comment,
    name: 'Jolio Mark',
    post: 'Designer',
    hits: '02 Hits',
    comments: '598 Comments',
    para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`,
  },
  {
    id: 3,
    src: Boy,
    name: 'Harf Mark',
    post: 'Designer',
    hits: '02 Hits',
    comments: '598 Comments',
    para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`,
  },
  {
    id: 4,
    src: comment,
    name: 'Zohn Cena',
    post: 'Designer',
    hits: '02 Hits',
    comments: '598 Comments',
    para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`,
  },
  {
    id: 5,
    src: Men,
    name: 'Robart Draf',
    post: 'Designer',
    hits: '02 Hits',
    comments: '598 Comments',
    para: `There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.`,
  },
];
