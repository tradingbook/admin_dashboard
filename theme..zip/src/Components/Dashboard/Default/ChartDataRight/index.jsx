import React, { Fragment } from 'react';
import SmallApexChart from './ApexChart';

const ChartDataRight = () => {
  return (
    <Fragment>
      <SmallApexChart />
    </Fragment>
  );
};
export default ChartDataRight;
