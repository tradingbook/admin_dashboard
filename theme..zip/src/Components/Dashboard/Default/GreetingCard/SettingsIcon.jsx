import React from 'react';

const SettingsIcon = () =>{
    return(
      <div className="badge f-12"><i className="fa fa-spin fa-cog f-14"></i></div>
    );
};

export default SettingsIcon;