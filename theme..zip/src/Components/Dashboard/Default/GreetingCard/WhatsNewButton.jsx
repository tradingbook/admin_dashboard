import React from 'react';

const WhatsNewButton = () =>{
    return(
      <div className="whatsnew-btn"><a className="btn btn-primary" href="#javascript">{'Whats New !'}</a></div>
    );
};

export default WhatsNewButton;