import React from 'react';

const NotificationIcon = () =>{
    return(
        <div className="left-icon"><i className="fa fa-bell"> </i></div>
    )
};

export default NotificationIcon;