# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

You need to install first npm, you can run:
### `npm i`

To run the project on local you need to run the below command:

### `npm run start-developer`

